<?php

/* lucky/number.html.twig */
class __TwigTemplate_19e0eddde4ca88926a0c822c6914d8df533a0fbf452862d9297b8cf016ee4f72 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("base.html.twig", "lucky/number.html.twig", 2);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c41dab7895b567f474b6e1159d93d14ce4b6ecca4763fd1d0702beab55e7888e = $this->env->getExtension("native_profiler");
        $__internal_c41dab7895b567f474b6e1159d93d14ce4b6ecca4763fd1d0702beab55e7888e->enter($__internal_c41dab7895b567f474b6e1159d93d14ce4b6ecca4763fd1d0702beab55e7888e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "lucky/number.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c41dab7895b567f474b6e1159d93d14ce4b6ecca4763fd1d0702beab55e7888e->leave($__internal_c41dab7895b567f474b6e1159d93d14ce4b6ecca4763fd1d0702beab55e7888e_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_b33f0d7eb3019053c049e31152aa73d55bfa881b5e84cfb9f681a556e268e064 = $this->env->getExtension("native_profiler");
        $__internal_b33f0d7eb3019053c049e31152aa73d55bfa881b5e84cfb9f681a556e268e064->enter($__internal_b33f0d7eb3019053c049e31152aa73d55bfa881b5e84cfb9f681a556e268e064_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "    <h1>Lucky Numbers: ";
        echo twig_escape_filter($this->env, (isset($context["luckyNumberList"]) ? $context["luckyNumberList"] : $this->getContext($context, "luckyNumberList")), "html", null, true);
        echo "</h1>
    <a href=\"";
        // line 6
        echo $this->env->getExtension('routing')->getPath("homepage");
        echo "\">Back to Home</a>
";
        
        $__internal_b33f0d7eb3019053c049e31152aa73d55bfa881b5e84cfb9f681a556e268e064->leave($__internal_b33f0d7eb3019053c049e31152aa73d55bfa881b5e84cfb9f681a556e268e064_prof);

    }

    public function getTemplateName()
    {
        return "lucky/number.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  45 => 6,  40 => 5,  34 => 4,  11 => 2,);
    }
}
/* {# app/Resources/views/lucky/number.html.twig #}*/
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block body %}*/
/*     <h1>Lucky Numbers: {{ luckyNumberList }}</h1>*/
/*     <a href="{{ path('homepage') }}">Back to Home</a>*/
/* {% endblock %}*/
