<?php

/* song/createsong.html.twig */
class __TwigTemplate_e030a30d7e9d8b8224ed1b41d7321766d7fbab65c524ca85a6a6ce11a1675e2a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("base.html.twig", "song/createsong.html.twig", 3);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8574d9b4b4d2e37aaae24c01bf71c604cd4d1a8c7ebc20278f0c3088e75e55cd = $this->env->getExtension("native_profiler");
        $__internal_8574d9b4b4d2e37aaae24c01bf71c604cd4d1a8c7ebc20278f0c3088e75e55cd->enter($__internal_8574d9b4b4d2e37aaae24c01bf71c604cd4d1a8c7ebc20278f0c3088e75e55cd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "song/createsong.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8574d9b4b4d2e37aaae24c01bf71c604cd4d1a8c7ebc20278f0c3088e75e55cd->leave($__internal_8574d9b4b4d2e37aaae24c01bf71c604cd4d1a8c7ebc20278f0c3088e75e55cd_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_9f3968e8c9deb42e21590277fb41c3b21014a0bb5243fd98e0636d6401975c46 = $this->env->getExtension("native_profiler");
        $__internal_9f3968e8c9deb42e21590277fb41c3b21014a0bb5243fd98e0636d6401975c46->enter($__internal_9f3968e8c9deb42e21590277fb41c3b21014a0bb5243fd98e0636d6401975c46_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    ";
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
\t";
        // line 7
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
\t";
        // line 8
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
";
        
        $__internal_9f3968e8c9deb42e21590277fb41c3b21014a0bb5243fd98e0636d6401975c46->leave($__internal_9f3968e8c9deb42e21590277fb41c3b21014a0bb5243fd98e0636d6401975c46_prof);

    }

    public function getTemplateName()
    {
        return "song/createsong.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 8,  45 => 7,  40 => 6,  34 => 5,  11 => 3,);
    }
}
/* {# app/Resources/views/song/createsong.html.twig #}*/
/* */
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block body %}*/
/*     {{ form_start(form) }}*/
/* 	{{ form_widget(form) }}*/
/* 	{{ form_end(form) }}*/
/* {% endblock %}*/
/* */
/* */
