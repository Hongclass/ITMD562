<?php

/* base.html.twig */
class __TwigTemplate_80966d25d7eb889eef6fe5fdb94e666c9eb0d0e0aab9949b645e708cb9047c5a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ec2c240942b86fb20d10199ca71b1d2e54f62221e8f9d0a66fb408f0c864b599 = $this->env->getExtension("native_profiler");
        $__internal_ec2c240942b86fb20d10199ca71b1d2e54f62221e8f9d0a66fb408f0c864b599->enter($__internal_ec2c240942b86fb20d10199ca71b1d2e54f62221e8f9d0a66fb408f0c864b599_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_ec2c240942b86fb20d10199ca71b1d2e54f62221e8f9d0a66fb408f0c864b599->leave($__internal_ec2c240942b86fb20d10199ca71b1d2e54f62221e8f9d0a66fb408f0c864b599_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_0f0c42f3f6bba58c7e9a5b101ca4191fcda3b46efe1329b7161848bf287be1d7 = $this->env->getExtension("native_profiler");
        $__internal_0f0c42f3f6bba58c7e9a5b101ca4191fcda3b46efe1329b7161848bf287be1d7->enter($__internal_0f0c42f3f6bba58c7e9a5b101ca4191fcda3b46efe1329b7161848bf287be1d7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_0f0c42f3f6bba58c7e9a5b101ca4191fcda3b46efe1329b7161848bf287be1d7->leave($__internal_0f0c42f3f6bba58c7e9a5b101ca4191fcda3b46efe1329b7161848bf287be1d7_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_bf468adacb00b4329baab7738148ca646e22682153b8faa4f12134aef1e41ca9 = $this->env->getExtension("native_profiler");
        $__internal_bf468adacb00b4329baab7738148ca646e22682153b8faa4f12134aef1e41ca9->enter($__internal_bf468adacb00b4329baab7738148ca646e22682153b8faa4f12134aef1e41ca9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_bf468adacb00b4329baab7738148ca646e22682153b8faa4f12134aef1e41ca9->leave($__internal_bf468adacb00b4329baab7738148ca646e22682153b8faa4f12134aef1e41ca9_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_beff30c6906b132371715e023e76c88eeeb16725f54da9068fbe663a6127854f = $this->env->getExtension("native_profiler");
        $__internal_beff30c6906b132371715e023e76c88eeeb16725f54da9068fbe663a6127854f->enter($__internal_beff30c6906b132371715e023e76c88eeeb16725f54da9068fbe663a6127854f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_beff30c6906b132371715e023e76c88eeeb16725f54da9068fbe663a6127854f->leave($__internal_beff30c6906b132371715e023e76c88eeeb16725f54da9068fbe663a6127854f_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_4493c73c1720f610412370447f8b38346178186b47503e80423dfc2ebc4af098 = $this->env->getExtension("native_profiler");
        $__internal_4493c73c1720f610412370447f8b38346178186b47503e80423dfc2ebc4af098->enter($__internal_4493c73c1720f610412370447f8b38346178186b47503e80423dfc2ebc4af098_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_4493c73c1720f610412370447f8b38346178186b47503e80423dfc2ebc4af098->leave($__internal_4493c73c1720f610412370447f8b38346178186b47503e80423dfc2ebc4af098_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 11,  82 => 10,  71 => 6,  59 => 5,  50 => 12,  47 => 11,  45 => 10,  38 => 7,  36 => 6,  32 => 5,  26 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/*     <head>*/
/*         <meta charset="UTF-8" />*/
/*         <title>{% block title %}Welcome!{% endblock %}</title>*/
/*         {% block stylesheets %}{% endblock %}*/
/*         <link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}" />*/
/*     </head>*/
/*     <body>*/
/*         {% block body %}{% endblock %}*/
/*         {% block javascripts %}{% endblock %}*/
/*     </body>*/
/* </html>*/
/* */
