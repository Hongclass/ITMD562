<?php

/* base.html.twig */
class __TwigTemplate_b83fea4d9015bb917e83ef7fa05d4adbc795131791e157620bce84104bbdf7c1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7dc1ad3cb7d7d027054e49d70442800c9023ae93b89c05129f043627976c0580 = $this->env->getExtension("native_profiler");
        $__internal_7dc1ad3cb7d7d027054e49d70442800c9023ae93b89c05129f043627976c0580->enter($__internal_7dc1ad3cb7d7d027054e49d70442800c9023ae93b89c05129f043627976c0580_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_7dc1ad3cb7d7d027054e49d70442800c9023ae93b89c05129f043627976c0580->leave($__internal_7dc1ad3cb7d7d027054e49d70442800c9023ae93b89c05129f043627976c0580_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_de30c65b4a21efa5d837b24f83f75c7737fe70c9ccf78472fe4c1581a4cd4e9d = $this->env->getExtension("native_profiler");
        $__internal_de30c65b4a21efa5d837b24f83f75c7737fe70c9ccf78472fe4c1581a4cd4e9d->enter($__internal_de30c65b4a21efa5d837b24f83f75c7737fe70c9ccf78472fe4c1581a4cd4e9d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_de30c65b4a21efa5d837b24f83f75c7737fe70c9ccf78472fe4c1581a4cd4e9d->leave($__internal_de30c65b4a21efa5d837b24f83f75c7737fe70c9ccf78472fe4c1581a4cd4e9d_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_01c2821f03d3417bff0970a76f24790e8733ba60533ca71527551e7ded36f154 = $this->env->getExtension("native_profiler");
        $__internal_01c2821f03d3417bff0970a76f24790e8733ba60533ca71527551e7ded36f154->enter($__internal_01c2821f03d3417bff0970a76f24790e8733ba60533ca71527551e7ded36f154_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_01c2821f03d3417bff0970a76f24790e8733ba60533ca71527551e7ded36f154->leave($__internal_01c2821f03d3417bff0970a76f24790e8733ba60533ca71527551e7ded36f154_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_4434f9616c97c0dbb26c1c136d6767f89f397d56ce5dba3342463d79e04a3dc3 = $this->env->getExtension("native_profiler");
        $__internal_4434f9616c97c0dbb26c1c136d6767f89f397d56ce5dba3342463d79e04a3dc3->enter($__internal_4434f9616c97c0dbb26c1c136d6767f89f397d56ce5dba3342463d79e04a3dc3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_4434f9616c97c0dbb26c1c136d6767f89f397d56ce5dba3342463d79e04a3dc3->leave($__internal_4434f9616c97c0dbb26c1c136d6767f89f397d56ce5dba3342463d79e04a3dc3_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_80409ee13e57c5c4a7ebd6c001d9ef0e79203eb1011369657159294a2b72087d = $this->env->getExtension("native_profiler");
        $__internal_80409ee13e57c5c4a7ebd6c001d9ef0e79203eb1011369657159294a2b72087d->enter($__internal_80409ee13e57c5c4a7ebd6c001d9ef0e79203eb1011369657159294a2b72087d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_80409ee13e57c5c4a7ebd6c001d9ef0e79203eb1011369657159294a2b72087d->leave($__internal_80409ee13e57c5c4a7ebd6c001d9ef0e79203eb1011369657159294a2b72087d_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 11,  82 => 10,  71 => 6,  59 => 5,  50 => 12,  47 => 11,  45 => 10,  38 => 7,  36 => 6,  32 => 5,  26 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/*     <head>*/
/*         <meta charset="UTF-8" />*/
/*         <title>{% block title %}Welcome!{% endblock %}</title>*/
/*         {% block stylesheets %}{% endblock %}*/
/*         <link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}" />*/
/*     </head>*/
/*     <body>*/
/*         {% block body %}{% endblock %}*/
/*         {% block javascripts %}{% endblock %}*/
/*     </body>*/
/* </html>*/
/* */
