<?php

/* lucky/number.html.twig */
class __TwigTemplate_da9005a5e2ee86ba3de20726bf4c285952f64b5f7172d132ac8e255fc34ac178 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("base.html.twig", "lucky/number.html.twig", 2);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bba97e5fc0484c76d76ee9071485c5cde81c98ee6544975e0871bd8f6275c106 = $this->env->getExtension("native_profiler");
        $__internal_bba97e5fc0484c76d76ee9071485c5cde81c98ee6544975e0871bd8f6275c106->enter($__internal_bba97e5fc0484c76d76ee9071485c5cde81c98ee6544975e0871bd8f6275c106_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "lucky/number.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_bba97e5fc0484c76d76ee9071485c5cde81c98ee6544975e0871bd8f6275c106->leave($__internal_bba97e5fc0484c76d76ee9071485c5cde81c98ee6544975e0871bd8f6275c106_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_378acc1003b93ca9a3da66fa469e5269103cd560cc1e1eadfb4aedf1cd51a619 = $this->env->getExtension("native_profiler");
        $__internal_378acc1003b93ca9a3da66fa469e5269103cd560cc1e1eadfb4aedf1cd51a619->enter($__internal_378acc1003b93ca9a3da66fa469e5269103cd560cc1e1eadfb4aedf1cd51a619_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "    <h1>Lucky Numbers: ";
        echo twig_escape_filter($this->env, (isset($context["luckyNumberList"]) ? $context["luckyNumberList"] : $this->getContext($context, "luckyNumberList")), "html", null, true);
        echo "</h1>
    <a href=\"";
        // line 6
        echo $this->env->getExtension('routing')->getPath("homepage");
        echo "\">Back to Home</a>
";
        
        $__internal_378acc1003b93ca9a3da66fa469e5269103cd560cc1e1eadfb4aedf1cd51a619->leave($__internal_378acc1003b93ca9a3da66fa469e5269103cd560cc1e1eadfb4aedf1cd51a619_prof);

    }

    public function getTemplateName()
    {
        return "lucky/number.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  45 => 6,  40 => 5,  34 => 4,  11 => 2,);
    }
}
/* {# app/Resources/views/lucky/number.html.twig #}*/
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block body %}*/
/*     <h1>Lucky Numbers: {{ luckyNumberList }}</h1>*/
/*     <a href="{{ path('homepage') }}">Back to Home</a>*/
/* {% endblock %}*/
