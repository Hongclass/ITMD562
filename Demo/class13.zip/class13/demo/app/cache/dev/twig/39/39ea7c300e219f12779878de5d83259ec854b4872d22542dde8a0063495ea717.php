<?php

/* song/createsong.html.twig */
class __TwigTemplate_c41a2ab24c971fdd8b5e8a0282fab30f4b9e5eee216b42be36f35fb497605731 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("base.html.twig", "song/createsong.html.twig", 3);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_46aef097255cb8d071ef092cb36b11bd8890a1175c222865502daa599c31373a = $this->env->getExtension("native_profiler");
        $__internal_46aef097255cb8d071ef092cb36b11bd8890a1175c222865502daa599c31373a->enter($__internal_46aef097255cb8d071ef092cb36b11bd8890a1175c222865502daa599c31373a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "song/createsong.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_46aef097255cb8d071ef092cb36b11bd8890a1175c222865502daa599c31373a->leave($__internal_46aef097255cb8d071ef092cb36b11bd8890a1175c222865502daa599c31373a_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_682ad8376c3f45bea71e695f568a9b9264f669ab9fbcc6b8ff78ac13d986e6bf = $this->env->getExtension("native_profiler");
        $__internal_682ad8376c3f45bea71e695f568a9b9264f669ab9fbcc6b8ff78ac13d986e6bf->enter($__internal_682ad8376c3f45bea71e695f568a9b9264f669ab9fbcc6b8ff78ac13d986e6bf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    ";
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
\t";
        // line 7
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
\t";
        // line 8
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
";
        
        $__internal_682ad8376c3f45bea71e695f568a9b9264f669ab9fbcc6b8ff78ac13d986e6bf->leave($__internal_682ad8376c3f45bea71e695f568a9b9264f669ab9fbcc6b8ff78ac13d986e6bf_prof);

    }

    public function getTemplateName()
    {
        return "song/createsong.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 8,  45 => 7,  40 => 6,  34 => 5,  11 => 3,);
    }
}
/* {# app/Resources/views/song/createsong.html.twig #}*/
/* */
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block body %}*/
/*     {{ form_start(form) }}*/
/* 	{{ form_widget(form) }}*/
/* 	{{ form_end(form) }}*/
/* {% endblock %}*/
/* */
/* */
