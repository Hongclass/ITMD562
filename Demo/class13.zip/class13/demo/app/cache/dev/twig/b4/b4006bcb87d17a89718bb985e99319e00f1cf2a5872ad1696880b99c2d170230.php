<?php

/* song/showsong.html.twig */
class __TwigTemplate_f69d2e71f3a2617100ba1e0c8cae5c5f9f10ba57d75216258ddb7862b90891dd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("base.html.twig", "song/showsong.html.twig", 3);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5c89fb5dba4dc1b2dc574cf41304defe83e259fa03e74a34915d0e2a0f6c3a1f = $this->env->getExtension("native_profiler");
        $__internal_5c89fb5dba4dc1b2dc574cf41304defe83e259fa03e74a34915d0e2a0f6c3a1f->enter($__internal_5c89fb5dba4dc1b2dc574cf41304defe83e259fa03e74a34915d0e2a0f6c3a1f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "song/showsong.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5c89fb5dba4dc1b2dc574cf41304defe83e259fa03e74a34915d0e2a0f6c3a1f->leave($__internal_5c89fb5dba4dc1b2dc574cf41304defe83e259fa03e74a34915d0e2a0f6c3a1f_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_3c3d6bd0ef94c53b715f88f92d52f504a56077b9857da01bea1c0303252fa53d = $this->env->getExtension("native_profiler");
        $__internal_3c3d6bd0ef94c53b715f88f92d52f504a56077b9857da01bea1c0303252fa53d->enter($__internal_3c3d6bd0ef94c53b715f88f92d52f504a56077b9857da01bea1c0303252fa53d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "<h1>All Songs</h1>
<table>
<tr>
\t<th>ID</th>
\t<th>Title</th>
\t<th>Rating</th>
</tr>
\t";
        // line 13
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["songList"]) ? $context["songList"] : $this->getContext($context, "songList")));
        foreach ($context['_seq'] as $context["_key"] => $context["song"]) {
            // line 14
            echo "\t<tr>
\t<td>";
            // line 15
            echo twig_escape_filter($this->env, $this->getAttribute($context["song"], "id", array()), "html", null, true);
            echo "</td>
        <td>";
            // line 16
            echo twig_escape_filter($this->env, $this->getAttribute($context["song"], "title", array()), "html", null, true);
            echo "</td>
        <td>";
            // line 17
            echo twig_escape_filter($this->env, $this->getAttribute($context["song"], "rating", array()), "html", null, true);
            echo "</td>
    </tr>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['song'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 20
        echo "</table>

<div>
                <h2>Back to Home</h2>
                <a href=\"";
        // line 24
        echo $this->env->getExtension('routing')->getPath("homepage");
        echo "\">Homepage</a>
            </div>
";
        
        $__internal_3c3d6bd0ef94c53b715f88f92d52f504a56077b9857da01bea1c0303252fa53d->leave($__internal_3c3d6bd0ef94c53b715f88f92d52f504a56077b9857da01bea1c0303252fa53d_prof);

    }

    public function getTemplateName()
    {
        return "song/showsong.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  79 => 24,  73 => 20,  64 => 17,  60 => 16,  56 => 15,  53 => 14,  49 => 13,  40 => 6,  34 => 5,  11 => 3,);
    }
}
/* {# app/Resources/views/song/showsong.html.twig #}*/
/* */
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block body %}*/
/* <h1>All Songs</h1>*/
/* <table>*/
/* <tr>*/
/* 	<th>ID</th>*/
/* 	<th>Title</th>*/
/* 	<th>Rating</th>*/
/* </tr>*/
/* 	{% for song in songList %}*/
/* 	<tr>*/
/* 	<td>{{song.id}}</td>*/
/*         <td>{{ song.title }}</td>*/
/*         <td>{{ song.rating }}</td>*/
/*     </tr>*/
/*     {% endfor %}*/
/* </table>*/
/* */
/* <div>*/
/*                 <h2>Back to Home</h2>*/
/*                 <a href="{{ path('homepage') }}">Homepage</a>*/
/*             </div>*/
/* {% endblock %}*/
/* */
/* */
