<?php

// Get Feed with curl
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'http://www.wsj.com/xml/rss/3_7085.xml');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
$results = curl_exec($ch);
curl_close($ch);
// print $results;

// Use simpleXML to parse rss xml to SimpleXMLElement Object
$xml = simplexml_load_string($results, 'SimpleXMLElement', LIBXML_NOCDATA);
// print_r($xml);

$json = json_encode($xml);
//print_r($json);
header('Content-Type: application/json');
print $json;

?>