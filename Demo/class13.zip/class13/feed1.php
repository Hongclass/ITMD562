<?php

// Get Feed with curl
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'http://www.wsj.com/xml/rss/3_7085.xml');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
$results = curl_exec($ch);
curl_close($ch);
// print $results;

// Use simpleXML to parse rss xml to SimpleXMLElement Object
$xml = simplexml_load_string($results, 'SimpleXMLElement', LIBXML_NOCDATA);
// print_r($xml);

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
<ul>
	<?php
		//print_r($xml->channel->item);
		foreach ($xml->channel->item as $story) {
			//print_r($story);
			$output = '<li>';
			$output .= '<h3>';
			$output .= '<a href="' . $story->link . '" target="_blank">' . $story->title . '</a>';
			$output .= '</h3>';
			$output .= '</li>';
			print $output;
		}
	?>
	</ul>
</body>
</html>